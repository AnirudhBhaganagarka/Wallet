package walletrestapis;

import java.util.ArrayList;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.wallet.mybeans.Wallet;
import com.wallet.mybeans.WalletOperatins;

@Path("/kyc")
public class WalletCall 
{
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
public ArrayList<Wallet> getkyc()
{
	ArrayList<Wallet> walletlist=new ArrayList<Wallet>();
	
	WalletOperatins wo = new WalletOperatins();
	walletlist=wo.getAllkyc();
	
	return(walletlist);
}
	@GET
	@Path("/{upi}")
	@Produces(MediaType.APPLICATION_JSON)
	public Wallet getwalletbal(@PathParam("upi") String id)
	{
		WalletOperatins obj=new WalletOperatins();
		Wallet ob=obj.SearchBal(id);
		
		return(ob);
	}
	
}
