package com.wallet.mybeans;

import java.util.ArrayList;
import java.sql.*;

public class WalletOperatins 
{
	public ArrayList<Wallet> getAllkyc()
	{
		ArrayList<Wallet> list = new ArrayList<Wallet>();
		Wallet obj;
		
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet?user=root&password=Microsoft");
			st=con.createStatement();
			rs=st.executeQuery("select * from kyc;");
			while(rs.next())
			{
				obj = new Wallet();
				obj.setWupi(rs.getString("wupi"));
				obj.setWbalance(rs.getDouble("wbalance"));
				list.add(obj);
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
			obj = new Wallet();
			obj.setWupi("Error");
			
		}
		
		return(list);		
	}
	
	public Wallet SearchBal(String upi)
	{
		Wallet obj= new Wallet();
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet?user=root&password=Microsoft");
			pst=con.prepareStatement("select wbalance from kyc where wupi=?;");
			pst.setString(1, upi);
			rs=pst.executeQuery();
	
			if(rs.next())
			{
				obj.setWupi(rs.getString("wupi"));
				obj.setWbalance(rs.getDouble("wbalance"));
				
			}
			else
			{
				obj.setWupi("Not Found");
				obj.setWbalance(0.0);
			}
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			obj.setWupi("Error");
			obj.setWbalance(0.0);
		}
		
		return(obj);
	}
	
}

