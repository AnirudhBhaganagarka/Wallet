package com.wallet.mybeans;

public class Wallet 
{
	private String wupi;
	private double wbalance;
	
	public Wallet()
	{
		wupi="";
		wbalance=0.0;
	}

	public String getWupi() {
		return wupi;
	}

	public void setWupi(String wupi) {
		this.wupi = wupi;
	}

	public double getWbalance() {
		return wbalance;
	}

	public void setWbalance(double wbalance) {
		this.wbalance = wbalance;
	}
	
}
